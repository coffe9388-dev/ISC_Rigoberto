
from flask import Flask, session, redirect, url_for, request, render_template, jsonify, flash
from flask_socketio import SocketIO, join_room, leave_room, emit
import hashlib
import time
import requests
import random
import uuid
import threading
from config import PUBLIC_KEY, PRIVATE_KEY, SECRET_KEY, DEBUG, HOST, PORT

app = Flask(__name__)
app.secret_key = SECRET_KEY

socketio = SocketIO(app, cors_allowed_origins="*", manage_session=False, ping_timeout=60, ping_interval=25)

game_rooms = {}
player_timers = {}

FALLBACK_CHARACTERS = [
    {"id":"1009610","name":"Spider-Man","image":"https://i.annihil.us/u/prod/marvel/i/mg/3/50/526548a343e4b.jpg"},
    {"id":"1009368","name":"Iron Man","image":"https://i.annihil.us/u/prod/marvel/i/mg/9/c0/527bb7b37ff55.jpg"},
    {"id":"1009220","name":"Captain America","image":"https://i.annihil.us/u/prod/marvel/i/mg/3/50/537ba56d31087.jpg"},
    {"id":"1009664","name":"Thor","image":"https://i.annihil.us/u/prod/marvel/i/mg/d/d0/5269657a74350.jpg"},
    {"id":"1009351","name":"Hulk","image":"https://i.annihil.us/u/prod/marvel/i/mg/5/a0/538615ca33ab0.jpg"},
    {"id":"1009189","name":"Black Widow","image":"https://i.annihil.us/u/prod/marvel/i/mg/f/30/50fecad1f395b.jpg"},
    {"id":"1009407","name":"Loki","image":"https://i.annihil.us/u/prod/marvel/i/mg/d/90/526547f509313.jpg"},
    {"id":"1009282","name":"Doctor Strange","image":"https://i.annihil.us/u/prod/marvel/i/mg/5/f0/5261a85a501fe.jpg"},
    {"id":"1009562","name":"Scarlet Witch","image":"https://i.annihil.us/u/prod/marvel/i/mg/6/70/5261a7d7c394b.jpg"},
    {"id":"1009697","name":"Vision","image":"https://i.annihil.us/u/prod/marvel/i/mg/9/d0/5111527040594.jpg"},
    {"id":"1009187","name":"Black Panther","image":"https://i.annihil.us/u/prod/marvel/i/mg/6/60/5261a80a67e7d.jpg"},
    {"id":"1009338","name":"Hawkeye","image":"https://i.annihil.us/u/prod/marvel/i/mg/e/90/50fecaf4f101b.jpg"},
    {"id":"1009268","name":"Deadpool","image":"https://i.annihil.us/u/prod/marvel/i/mg/9/90/5261a86cacb99.jpg"},
    {"id":"1009718","name":"Wolverine","image":"https://i.annihil.us/u/prod/marvel/i/mg/2/60/537bcaef0f6cf.jpg"},
    {"id":"1009378","name":"Nick Fury","image":"https://i.annihil.us/u/prod/marvel/i/mg/3/c0/5261a745e658d.jpg"},
    {"id":"1009471","name":"Magneto","image":"https://i.annihil.us/u/prod/marvel/i/mg/3/b0/5261a7e53f827.jpg"},
    {"id":"1009175","name":"Beast","image":"https://i.annihil.us/u/prod/marvel/i/mg/2/80/511a79a0451a3.jpg"},
    {"id":"1009257","name":"Cyclops","image":"https://i.annihil.us/u/prod/marvel/i/mg/6/70/526547e2d90ad.jpg"},
    {"id":"1009629","name":"Storm","image":"https://i.annihil.us/u/prod/marvel/i/mg/6/40/526963dad214d.jpg"},
    {"id":"1010743","name":"Groot","image":"https://i.annihil.us/u/prod/marvel/i/mg/3/10/526033c8b474a.jpg"},
    {"id":"1009652","name":"Thanos","image":"https://i.annihil.us/u/prod/marvel/i/mg/6/40/5274137e3e2cd.jpg"},
    {"id":"1009522","name":"Professor X","image":"https://i.annihil.us/u/prod/marvel/i/mg/3/e0/528d3378de525.jpg"},
    {"id":"1009592","name":"Silver Surfer","image":"https://i.annihil.us/u/prod/marvel/i/mg/3/50/527bb6490a176.jpg"},
    {"id":"1009262","name":"Daredevil","image":"https://i.annihil.us/u/prod/marvel/i/mg/6/90/537ba6d49472b.jpg"},
    
    
]

def marvel_hash_params():
    ts = str(int(time.time()))
    hash_input = (ts + (PRIVATE_KEY or "") + (PUBLIC_KEY or "")).encode('utf-8')
    h = hashlib.md5(hash_input).hexdigest()
    return ts, PUBLIC_KEY, h

def fetch_characters(limit=50):
    if not PUBLIC_KEY or not PRIVATE_KEY:
        app.logger.warning("⚠️ Usando personajes de respaldo")
        return FALLBACK_CHARACTERS
    try:
        ts, apikey, h = marvel_hash_params()
        offset = random.choice([0, 100, 200, 300, 400, 500])
        params = {"ts": ts, "apikey": apikey, "hash": h, "limit": limit, "offset": offset, "orderBy": "name"}
        r = requests.get("https://gateway.marvel.com/v1/public/characters", params=params, timeout=10)
        r.raise_for_status()
        data = r.json()
        chars = []
        for item in data.get("data", {}).get("results", []):
            thumbnail = item.get("thumbnail", {})
            image_path = thumbnail.get("path", "")
            image_ext = thumbnail.get("extension", "jpg")
            image_url = f"{image_path}.{image_ext}"
            if image_path and "image_not_available" not in image_url:
                chars.append({"id": str(item.get("id")), "name": item.get("name"), "image": image_url})
        if len(chars) < 15:
            return FALLBACK_CHARACTERS
        app.logger.info(f"✅ {len(chars)} personajes de Marvel API")
        return chars[:40]
    except Exception as e:
        app.logger.warning(f"⚠️ Error API: {e}")
        return FALLBACK_CHARACTERS

def create_room():
    room_id = str(uuid.uuid4())[:8].upper()
    game_rooms[room_id] = {
        "players": {},
        "turn": None,
        "awaiting_answer": False,
        "last_question": None,
        "qa": [],
        "winner": None,
        "winner_name": None,
        "started": False,
        "created_at": time.time()
    }
    return room_id

def get_room(room_id):
    return game_rooms.get(room_id)

def get_player_by_socket(room_id, socket_id):
    room = get_room(room_id)
    if not room: return None
    for pid, player in room["players"].items():
        if player.get("socket_id") == socket_id:
            return pid
    return None

def is_valid_player_name(name):
    if not name or not isinstance(name, str): return False
    name = name.strip()
    return 2 <= len(name) <= 50

def cancel_removal_timer(room_id, player_id):
    timer_key = f"{room_id}:{player_id}"
    if timer_key in player_timers:
        timer = player_timers[timer_key]
        if timer and timer.is_alive():
            timer.cancel()
            app.logger.info(f"⏱️ Timer cancelado para {player_id}")
        del player_timers[timer_key]

def remove_player_from_room(room_id, player_id):
    try:
        room = game_rooms.get(room_id)
        if not room:
            return
        player = room["players"].get(player_id)
        if not player:
            return
        player_name = player.get("name", "Jugador")
        del room["players"][player_id]
        app.logger.info(f"🗑️ Eliminado {player_name} de {room_id}")
        
        #  CRÍTICO: Emitir a TODA la sala
        socketio.emit("player_left", {
            "player_name": player_name, 
            "player_id": player_id
        }, room=room_id, namespace='/')
        
        cancel_removal_timer(room_id, player_id)
        
        if len(room["players"]) == 0:
            del game_rooms[room_id]
            app.logger.info(f"🗑️ Sala {room_id} eliminada")
    except Exception as e:
        app.logger.exception("Error en remove_player_from_room: %s", e)

def schedule_remove_player(room_id, player_id, delay_seconds=15):
    def _remove():
        time.sleep(delay_seconds)
        room = game_rooms.get(room_id)
        if not room:
            return
        player = room["players"].get(player_id)
        if not player:
            return
        if player.get("last_disconnect"):
            time_since_disconnect = time.time() - player["last_disconnect"]
            if time_since_disconnect < delay_seconds:
                app.logger.info(f"✅ {player_id} reconectado, timer cancelado")
                return
        remove_player_from_room(room_id, player_id)
    
    timer_key = f"{room_id}:{player_id}"
    cancel_removal_timer(room_id, player_id)
    
    timer = threading.Timer(delay_seconds, _remove)
    player_timers[timer_key] = timer
    timer.start()

# ==================== RUTAS ====================

@app.route("/")
def index():
    return render_template("index_online.html")

@app.route("/test")
def test_connection():
    return render_template("test_connection.html")

@app.route("/create_room")
def create_room_route():
    room_id = create_room()
    app.logger.info(f"🎮 Sala creada: {room_id}")
    return redirect(url_for("lobby", room_id=room_id))

@app.route("/join/<room_id>")
def join_room_route(room_id):
    room_id = room_id.upper()
    room = get_room(room_id)
    if not room:
        flash("❌ Sala no encontrada")
        return redirect(url_for("index"))
    if len(room["players"]) >= 2:
        flash("❌ Sala llena")
        return redirect(url_for("index"))
    return redirect(url_for("lobby", room_id=room_id))

@app.route("/lobby/<room_id>")
def lobby(room_id):
    room_id = room_id.upper()
    room = get_room(room_id)
    if not room:
        flash("❌ Sala no encontrada")
        return redirect(url_for("index"))
    return render_template("lobby.html", room_id=room_id, room=room)

@app.route("/select/<room_id>/<player_id>")
def select_character(room_id, player_id):
    room_id = room_id.upper()
    room = get_room(room_id)
    if not room:
        flash("❌ Sala no encontrada")
        return redirect(url_for("index"))
    if player_id not in room["players"]:
        flash("❌ No estás registrado")
        return redirect(url_for("lobby", room_id=room_id))
    chars = FALLBACK_CHARACTERS
    return render_template("select_online.html", room_id=room_id, player_id=player_id, characters=chars)

@app.route("/game/<room_id>/<player_id>")
def game(room_id, player_id):
    room_id = room_id.upper()
    room = get_room(room_id)
    if not room:
        flash("❌ Sala no encontrada")
        return redirect(url_for("index"))
    if player_id not in room["players"]:
        flash("❌ No estás registrado")
        return redirect(url_for("index"))
    if not room.get("started"):
        flash("⏳ El juego aún no comenzó")
        return redirect(url_for("lobby", room_id=room_id))
    return render_template("game_online.html", room_id=room_id, room=room, player_id=player_id)

# ==================== WEBSOCKET ====================

@socketio.on("connect")
def handle_connect():
    app.logger.info(f"🔌 Conectado: {request.sid}")

@socketio.on("join")
def handle_join(data):
    """Handler para que el cliente se una explícitamente a la sala"""
    room = data.get("room", "").upper()
    if room and room in game_rooms:
        join_room(room)
        emit("joined", {"room": room}, room=request.sid)
        app.logger.info(f"👥 {request.sid} unido a sala {room}")
    else:
        app.logger.warning(f"⚠️ Intento de unirse a sala inválida: {room}")

@socketio.on("disconnect")
def handle_disconnect():
    sid = request.sid
    app.logger.info(f"🔌 Desconectado: {sid}")
    
    for room_id, room in list(game_rooms.items()):
        for pid, player in list(room["players"].items()):
            if player.get("socket_id") == sid:
                player_name = player.get("name", "Jugador")
                player["last_disconnect"] = time.time()
                app.logger.info(f"⚠️ {player_name} desconectado de {room_id}")
                schedule_remove_player(room_id, pid, delay_seconds=15)
                break

@socketio.on("join_lobby")
def handle_join_lobby(data):
    room_id = data.get("room_id", "").upper()
    player_name = (data.get("player_name") or "").strip()
    
    if not is_valid_player_name(player_name):
        emit("error", {"message": "❌ Nombre inválido"}, room=request.sid)
        return
    
    room = get_room(room_id)
    if not room:
        emit("error", {"message": "❌ Sala no encontrada"}, room=request.sid)
        return
    
    existing_player_id = get_player_by_socket(room_id, request.sid)
    if existing_player_id:
        player = room["players"][existing_player_id]
        player["socket_id"] = request.sid
        player["last_disconnect"] = None
        cancel_removal_timer(room_id, existing_player_id)
        join_room(room_id)
        app.logger.info(f"🔄 {player_name} reconectado como {existing_player_id}")
        
        #  CRÍTICO: Emitir a TODA la sala
        emit("player_joined", {
            "players": room["players"], 
            "player_id": existing_player_id, 
            "room_id": room_id
        }, room=room_id)
        return
    
    if len(room["players"]) >= 2:
        emit("error", {"message": "❌ Sala llena"}, room=request.sid)
        return
    
    player_id = "p1" if "p1" not in room["players"] else "p2"
    
    room["players"][player_id] = {
        "name": player_name,
        "character": None,
        "character_name": None,
        "character_image": None,
        "socket_id": request.sid,
        "ready": False,
        "joined_at": time.time(),
        "last_disconnect": None
    }
    
    join_room(room_id)
    app.logger.info(f"👤 {player_name} ({player_id}) → {room_id}")
    
    #  CRÍTICO: Emitir a TODA la sala
    emit("player_joined", {
        "players": room["players"], 
        "player_id": player_id, 
        "room_id": room_id
    }, room=room_id)

@socketio.on("select_character")
def handle_select_character(data):
    room_id = data.get("room_id", "").upper()
    player_id = data.get("player_id")
    char_id = data.get("char_id")
    char_name = (data.get("char_name") or "").strip()
    char_image = data.get("char_image") or ""
    
    room = get_room(room_id)
    if not room or player_id not in room["players"]:
        emit("error", {"message": "❌ Error en sala"}, room=request.sid)
        return
    if not char_name or not char_id:
        emit("error", {"message": "❌ Personaje inválido"}, room=request.sid)
        return
    
    room["players"][player_id]["character"] = char_id
    room["players"][player_id]["character_name"] = char_name
    room["players"][player_id]["character_image"] = char_image
    room["players"][player_id]["ready"] = True
    
    app.logger.info(f"✅ {room['players'][player_id]['name']} → {char_name}")
    
    all_ready = len(room["players"]) == 2 and all(p.get("ready") for p in room["players"].values())
    
    #  CRÍTICO: Emitir a TODA la sala
    emit("player_ready", {
        "player_id": player_id, 
        "player_name": room["players"][player_id]["name"], 
        "all_ready": all_ready
    }, room=room_id)
    
    if all_ready:
        room["started"] = True
        room["turn"] = "p1"
        app.logger.info(f"⚡ Juego iniciado en {room_id}")
        
        #  CRÍTICO: Emitir a TODA la sala
        emit("game_started", {
            "room": room, 
            "room_id": room_id
        }, room=room_id)

@socketio.on("ask_question")
def handle_ask_question(data):
    room_id = data.get("room_id", "").upper()
    player_id = data.get("player_id")
    question = (data.get("question") or "").strip()
    
    room = get_room(room_id)
    if not room or player_id not in room["players"]:
        emit("error", {"message": "❌ Error"}, room=request.sid)
        return
    if not question or len(question) < 3:
        emit("error", {"message": "❌ Pregunta muy corta"}, room=request.sid)
        return
    if len(question) > 500:
        emit("error", {"message": "❌ Pregunta muy larga"}, room=request.sid)
        return
    if room.get("turn") != player_id:
        emit("error", {"message": "❌ No es tu turno"}, room=request.sid)
        return
    if room.get("awaiting_answer"):
        emit("error", {"message": "⏳ Pregunta pendiente"}, room=request.sid)
        return
    
    room["last_question"] = question
    room["awaiting_answer"] = True
    room["qa"].append({
        "asker": player_id, 
        "asker_name": room["players"][player_id]["name"], 
        "question": question, 
        "answer": None, 
        "timestamp": time.time()
    })
    
    app.logger.info(f"❓ {room['players'][player_id]['name']}: {question}")
    
    #  CRÍTICO: Emitir a TODA la sala (no solo al que pregunta)
    emit("question_asked", {
        "question": question, 
        "asker": player_id, 
        "asker_name": room["players"][player_id]["name"],
        "qa": room["qa"]  # Enviar historial completo
    }, room=room_id)

@socketio.on("answer_question")
def handle_answer_question(data):
    room_id = data.get("room_id", "").upper()
    player_id = data.get("player_id")
    answer = (data.get("answer") or "").strip()
    
    room = get_room(room_id)
    if not room or player_id not in room["players"]:
        emit("error", {"message": "❌ Error"}, room=request.sid)
        return
    if not answer or len(answer) < 2:
        emit("error", {"message": "❌ Respuesta muy corta"}, room=request.sid)
        return
    if len(answer) > 500:
        emit("error", {"message": "❌ Respuesta muy larga"}, room=request.sid)
        return
    if room.get("turn") == player_id:
        emit("error", {"message": "❌ No respondas tu propia pregunta"}, room=request.sid)
        return
    if not room.get("awaiting_answer"):
        emit("error", {"message": "❌ No hay pregunta pendiente"}, room=request.sid)
        return
    
    for qa in reversed(room["qa"]):
        if qa.get("answer") is None:
            qa["answer"] = answer
            qa["responder"] = player_id
            qa["responder_name"] = room["players"][player_id]["name"]
            qa["answer_timestamp"] = time.time()
            break
    
    room["awaiting_answer"] = False
    room["last_question"] = None
    room["turn"] = "p2" if room["turn"] == "p1" else "p1"
    
    app.logger.info(f"💬 {room['players'][player_id]['name']}: {answer}")
    
    #  CRÍTICO: Emitir a TODA la sala
    emit("question_answered", {
        "answer": answer, 
        "responder": player_id, 
        "responder_name": room["players"][player_id]["name"], 
        "new_turn": room["turn"], 
        "qa": room["qa"]
    }, room=room_id)

@socketio.on("make_guess")
def handle_make_guess(data):
    room_id = data.get("room_id", "").upper()
    player_id = data.get("player_id")
    guess = (data.get("guess") or "").strip().lower()
    
    room = get_room(room_id)
    if not room or player_id not in room["players"]:
        emit("error", {"message": "❌ Error"}, room=request.sid)
        return
    if not guess or len(guess) < 2:
        emit("error", {"message": "❌ Nombre muy corto"}, room=request.sid)
        return
    if len(guess) > 100:
        emit("error", {"message": "❌ Nombre muy largo"}, room=request.sid)
        return
    if room.get("turn") != player_id:
        emit("error", {"message": "❌ No es tu turno"}, room=request.sid)
        return
    
    opponent_id = "p2" if player_id == "p1" else "p1"
    if opponent_id not in room["players"] or not room["players"][opponent_id].get("character_name"):
        emit("error", {"message": "❌ Error en el juego"}, room=request.sid)
        return
    
    target_name = room["players"][opponent_id]["character_name"].lower()
    
    is_correct = (
        guess == target_name or
        guess in target_name or
        target_name in guess or
        guess.replace("-", " ").replace("'", "") in target_name.replace("-", " ").replace("'", "")
    )
    
    if is_correct:
        room["winner"] = player_id
        room["winner_name"] = room["players"][player_id]["name"]
        app.logger.info(f"🏆 {room['winner_name']} GANÓ!")
        
        #  CRÍTICO: Emitir a TODA la sala
        emit("game_won", {
            "winner_id": player_id, 
            "winner_name": room["winner_name"], 
            "correct_character": room["players"][opponent_id]["character_name"], 
            "character_image": room["players"][opponent_id]["character_image"]
        }, room=room_id)
    else:
        room["qa"].append({
            "asker": player_id, 
            "asker_name": room["players"][player_id]["name"], 
            "question": f"🎲 INTENTO: {guess.upper()}", 
            "answer": "❌ INCORRECTO", 
            "responder_name": "Sistema", 
            "timestamp": time.time()
        })
        room["turn"] = opponent_id
        app.logger.info(f"❌ Intento fallido: {guess}")
        
        #  CRÍTICO: Emitir a TODA la sala
        emit("guess_failed", {
            "guess": guess, 
            "guesser_name": room["players"][player_id]["name"], 
            "new_turn": room["turn"], 
            "qa": room["qa"]
        }, room=room_id)

@socketio.on("request_game_state")
def handle_request_game_state(data):
    room_id = data.get("room_id", "").upper()
    player_id = data.get("player_id")
    
    room = get_room(room_id)
    if not room:
        emit("error", {"message": "❌ Sala no encontrada"}, room=request.sid)
        return
    if not player_id or player_id not in room["players"]:
        emit("error", {"message": "❌ Jugador no encontrado"}, room=request.sid)
        return
    
    if room["players"][player_id].get("socket_id") != request.sid:
        room["players"][player_id]["socket_id"] = request.sid
        room["players"][player_id]["last_disconnect"] = None
        cancel_removal_timer(room_id, player_id)
        join_room(room_id)
        app.logger.info(f"🔄 {room['players'][player_id]['name']} reconectado")
    
    #  Emitir solo al jugador que pidió el estado
    emit("game_state_update", {
        "room": room, 
        "player_id": player_id
    }, room=request.sid)

if __name__ == "__main__":
    print("=" * 60)
    print("🦸 MARVEL GUESS DUEL - MULTIPLAYER")
    print("=" * 60)
    print("✅ Sincronización en tiempo real")
    print(f"🌐 http://localhost:{PORT}")
    print("=" * 60 + "\n")
    socketio.run(app, debug=DEBUG, host=HOST, port=PORT, allow_unsafe_werkzeug=True)