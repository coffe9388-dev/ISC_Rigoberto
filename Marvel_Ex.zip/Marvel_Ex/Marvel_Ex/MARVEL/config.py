

PUBLIC_KEY = "db94f6e113c5786d69603a87fd1ce9c8"
PRIVATE_KEY = "4828a2653e32e9e500c93255327ecc0bec26fd6a"

# ============================================================
# FLASK CONFIGURATION
# ============================================================

# Clave secreta para sesiones de Flask
# IMPORTANTE: Cambia esto en producción por una clave única y segura
SECRET_KEY = "marvel_secret_super_secure_2024_change_this_in_production"

# Modo debug (True para desarrollo, False para producción)
DEBUG = True

# Host (0.0.0.0 permite conexiones externas, localhost solo locales)
HOST = "0.0.0.0"

# Puerto del servidor
PORT = 5000

# ============================================================
# GAME CONFIGURATION
# ============================================================

# Número máximo de jugadores por sala
MAX_PLAYERS_PER_ROOM = 2

# Tiempo máximo de inactividad antes de eliminar sala (segundos)
ROOM_TIMEOUT = 3600  # 1 hora

# Límite de caracteres para preguntas y respuestas
MAX_QUESTION_LENGTH = 500
MAX_ANSWER_LENGTH = 500
MAX_GUESS_LENGTH = 100

# ============================================================
# DESARROLLO Y PRUEBAS
# ============================================================

# Si True, imprime información de debug en consola
VERBOSE_LOGGING = True

# Si True, permite CORS desde cualquier origen (solo para desarrollo)
ALLOW_CORS = True