from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

API_BASE_URL = "https://pokeapi.co/api/v2"

# ------------------- RUTAS -------------------

@app.route('/')
def home():
    """Página principal con descripción"""
    return render_template('index.html')

@app.route('/pokemon')
def listar_pokemones():
    """Obtiene una lista de pokémon"""
    limit = request.args.get('limit', 1000)
    response = requests.get(f"{API_BASE_URL}/pokemon?limit={limit}")

    if response.status_code == 200:
        data = response.json()
        pokemones = data.get('results', [])
        return render_template('pokemon.html', pokemones=pokemones)
    else:
        return "Error al obtener pokemones", 404

@app.route('/pokemon/<nombre>')
def mostrar_pokemon(nombre):
    """Obtiene información de un pokémon específico"""
    response = requests.get(f"{API_BASE_URL}/pokemon/{nombre.lower()}")

    if response.status_code == 200:
        pokemon = response.json()
        return render_template('pokemon_detalle.html', pokemon=pokemon)
    else:
        return "Pokémon no encontrado", 404

@app.route('/api/buscar', methods=['POST'])
def buscar_pokemon():
    """Busca un Pokémon por nombre (vía JSON o formulario)"""
    nombre = request.form.get('nombre') or request.json.get('nombre')
    if not nombre:
        return jsonify({"error": "Falta el nombre del Pokémon"}), 400

    response = requests.get(f"{API_BASE_URL}/pokemon/{nombre.lower()}")
    if response.status_code == 200:
        return jsonify(response.json()), 200
    else:
        return jsonify({"error": "Pokémon no encontrado"}), 404
    
@app.route('/buscar', methods=['POST'])
def buscar():
    """Busca un Pokémon por nombre desde el formulario"""
    nombre = request.form.get('nombre')
    if not nombre:
        return "Debes escribir un nombre", 400

    response = requests.get(f"{API_BASE_URL}/pokemon/{nombre.lower()}")
    
    if response.status_code == 200:
        pokemon = response.json()
        # Renderizamos la plantilla de detalle con la info encontrada
        return render_template('pokemon_detalle.html', pokemon=pokemon)
    else:
        return render_template('pokemon_no_encontrado.html', nombre=nombre)


# ------------------- EJECUCIÓN -------------------
if __name__ == '__main__':
    app.run(debug=True)
