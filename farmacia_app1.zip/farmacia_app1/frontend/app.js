// app.js
function mostrarDetalles(producto) {
    // Puedes mostrar los detalles en un div, modal, alerta, etc.
    // Aquí lo haremos en un div con id="detalles-producto"
    const detallesDiv = document.getElementById('detalles-producto');
    detallesDiv.innerHTML = `
        <h2>Detalles del Producto</h2>
        <p><strong>ID:</strong> ${producto.id_producto}</p>
        <p><strong>Nombre:</strong> ${producto.nombre}</p>
        <p><strong>Precio Venta:</strong> ${producto.precio_venta}</p>
        <p><strong>Marca:</strong> ${producto.marca}</p>
        <p><strong>Presentación:</strong> ${producto.presentacion}</p>
        <p><strong>Categoría:</strong> ${producto.id_categoria}</p>
        <!-- Agrega más campos si quieres -->
    `;
}

fetch('http://localhost:3000/productos')
    .then(response => response.json())
    .then(productos => {
        const tbody = document.querySelector('#tabla-productos tbody');
        productos.forEach(producto => {
            const fila = document.createElement('tr');
            fila.innerHTML = `
                <td>${producto.id_producto}</td>
                <td>${producto.nombre}</td>
                <td>${producto.precio_venta}</td>
                <td>${producto.id_categoria}</td>
            `;
            // Agrega el evento click a la fila
            fila.addEventListener('click', () => {
                // Consulta el endpoint de detalles
                fetch(`http://localhost:3000/productos/${producto.id_producto}`)
                    .then(res => res.json())
                    .then(detalle => mostrarDetalles(detalle))
                    .catch(error => {
                        alert('Error al cargar los detalles');
                        console.error(error);
                    });
            });
            tbody.appendChild(fila);
        });
    })
    .catch(error => {
        alert('Error al cargar los productos');
        console.error(error);
    });
    // Actualizar un producto por ID
app.put('/productos/:id', (req, res) => {
    const id = req.params.id;
    const {
        nombre, descripcion, marca, presentacion, principio_activo, concentracion,
        codigo_barras, lote, laboratorio, precio_compra, precio_venta,
        id_categoria, requiere_receta, fecha_vencimiento
    } = req.body;

    // Validación básica de campos obligatorios
    if (!nombre || precio_compra === undefined || precio_venta === undefined || !id_categoria) {
        return res.status(400).json({ error: 'Faltan datos obligatorios' });
    }

    const sql = `
        UPDATE productos SET
            nombre = ?,
            descripcion = ?,
            marca = ?,
            presentacion = ?,
            principio_activo = ?,
            concentracion = ?,
            codigo_barras = ?,
            lote = ?,
            laboratorio = ?,
            precio_compra = ?,
            precio_venta = ?,
            id_categoria = ?,
            requiere_receta = ?,
            fecha_vencimiento = ?
        WHERE id_producto = ?
    `;

    const valores = [
        nombre, descripcion, marca, presentacion, principio_activo, concentracion,
        codigo_barras, lote, laboratorio, precio_compra, precio_venta,
        id_categoria, requiere_receta, fecha_vencimiento, id
    ];

    db.query(sql, valores, (error, result) => {
        if (error) {
            console.error('Error al actualizar producto:', error);
            return res.status(500).json({ error: 'Error al actualizar producto' });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Producto no encontrado' });
        }
        res.json({ mensaje: 'Producto actualizado correctamente' });
    });
});