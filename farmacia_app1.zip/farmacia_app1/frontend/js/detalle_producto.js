// js/detalle_producto.js

// Obtener el id de la URL
const params = new URLSearchParams(window.location.search);
const id = params.get('id');

if (!id) {
    document.getElementById('detalle-producto').innerHTML = '<p>Error: No se especificó el producto.</p>';
} else {
    fetch(`http://localhost:3000/productos/${id}`)
        .then(res => res.json())
        .then(producto => {
            if (producto.error) {
                document.getElementById('detalle-producto').innerHTML = `<p>${producto.error}</p>`;
            } else {
                document.getElementById('detalle-producto').innerHTML = `
                    <ul>
                        <li><strong>ID:</strong> ${producto.id_producto}</li>
                        <li><strong>Nombre:</strong> ${producto.nombre}</li>
                        <li><strong>Precio Venta:</strong> ${producto.precio_venta}</li>
                        <li><strong>Marca:</strong> ${producto.marca || '-'}</li>
                        <li><strong>Presentación:</strong> ${producto.presentacion || '-'}</li>
                        <li><strong>Categoría:</strong> ${producto.id_categoria}</li>
                        <!-- Agrega más campos si quieres -->
                    </ul>
                `;
            }
        })
        .catch(error => {
            document.getElementById('detalle-producto').innerHTML = '<p>Error al cargar el producto.</p>';
            console.error(error);
        });
}