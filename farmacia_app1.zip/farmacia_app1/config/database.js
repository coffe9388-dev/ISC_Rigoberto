//Importa la librería mysql2, que es un cliente MySQL para Node.js
//  que permite conectarse y realizar operaciones en bases de datos MySQL.
const mysql = require('mysql2');
//Crea una conexión a MySQL usando createConnection() y la almacena en la constante connection.
// Recibe un objeto con los parámetros de conexión.
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',        // Cambia por tu usuario de MySQL
    password: 'root',        // Cambia por tu contraseña de MySQL
    database: 'farmacia'
});
// Conectar a la base de datos
//Ejecuta la conexión a la base de datos. 
// Recibe una función callback que se ejecuta cuando la conexión termina 
// (exitosa o con error).
connection.connect((error) => {
    if (error) {
        console.error(' Error conectando a la base de datos:', error);
        return;
    }
    console.log('Conectado a la base de datos MySQL');
});
//: Exporta el objeto connection 
// para que otros archivos puedan importarlo y usar la conexión a la base de datos.
module.exports = connection;