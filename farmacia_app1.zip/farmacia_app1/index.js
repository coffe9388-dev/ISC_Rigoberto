// index.js
//Importa el framework Express.js usando require().
// Express es un framework web para Node.js que facilita crear servidores HTTP.
const express = require('express');
//Importa la librería mysql2 para conectarse a bases de datos MySQL.
// Aunque se importa, no se usa en este código.
const mysql = require('mysql2');
//Crea una instancia de la aplicación Express llamada app.
// Esta será la aplicación principal del servidor.
const app = express();
//Define una constante PORT con el valor 3000,
//que será el puerto donde correrá el servidor.
const cors = require('cors');
app.use(cors());
const PORT = 3000;
const path = require('path');
app.use(express.static(path.join(__dirname, 'frontend')));

//agregado por  conexion
const db = require('./config/database');

// Middleware para parsear JSON
//Configura un middleware que permite al servidor 
//parsear automáticamente el JSON que llegue en las peticiones HTTP.
app.use(express.json());

// Ruta básica de prueba
//Define una ruta GET para la raíz del servidor (/).
// Recibe dos parámetros: req (request/petición) y res (response/respuesta).
app.get('/', (req, res) => {
    res.json({ 
        mensaje: 'Servidor de Farmacia funcionando correctamente!',
        version: '1.0.0'
    });
});
// Ruta de prueba para la base de datos
//Define una ruta GET en el endpoint /test-db. 
//Cuando alguien visite esta URL, se ejecutará la función con parámetros
//req (petición) y res (respuesta).
app.get('/test-db', (req, res) => {
    db.query('SELECT COUNT(*) as total FROM productos', (error, results) => {
        if (error) {
            return res.status(500).json({ error: 'Error en la base de datos' });
        }
        res.json({ 
            mensaje: 'Conexión a la base de datos exitosa',
            total_productos: results[0].total
        });
    });
});
// Obtener todos los productos
app.get('/productos', (req, res) => {
    db.query('SELECT * FROM productos', (error, results) => {
        if (error) {
            return res.status(500).json({ error: 'Error al obtener productos' });
        }
        res.json(results);
    });
});
//sucursales
// Obtener todas las sucursales
app.get('/sucursales', (req, res) => {
    db.query('SELECT * FROM sucursales', (error, results) => {
        if (error) {
            return res.status(500).json({ error: 'Error al obtener las sucursales' });
        }
        res.json(results);
    });
});
//
// Obtener todos los empleados
app.get('/empleados', (req, res) => {
    db.query('SELECT * FROM empleados', (error, results) => {
        if (error) {
            return res.status(500).json({ error: 'Error al obtener empleados' });
        }
        res.json(results);
    });
});
//consulta producto por ID 
// Obtener un producto por ID
app.get('/productos/:id', (req, res) => {
    const id = req.params.id;
    
    db.query('SELECT * FROM productos WHERE id_producto = ?', [id], (error, results) => {
        if (error) {
            return res.status(500).json({ error: 'Error al obtener el producto' });
        }
        
        // Si no se encontró el producto
        if (results.length === 0) {
            return res.status(404).json({ error: 'Producto no encontrado' });
        }
        
        // Devolver solo el primer resultado (debería ser único)
        res.json(results[0]);
    });
});
app.post('/productos', (req, res) => {
    const {
        nombre, descripcion, marca, presentacion, principio_activo, concentracion,
        codigo_barras, lote, laboratorio, precio_compra, precio_venta, 
        id_categoria, requiere_receta, fecha_vencimiento
    } = req.body;

    // Validación básica de campos obligatorios
    if (!nombre || precio_compra === undefined || precio_venta === undefined || !id_categoria) {
        return res.status(400).json({ error: 'Faltan datos obligatorios' });
    }

    // Prepara la consulta SQL
    const sql = `
        INSERT INTO productos
        (nombre, descripcion, marca, presentacion, principio_activo, concentracion,
         codigo_barras, lote, laboratorio, precio_compra, precio_venta, 
         id_categoria, requiere_receta, fecha_vencimiento, estado)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "activo")
    `;

    // Prepara los valores en el mismo orden que la consulta
    const valores = [
        nombre, descripcion, marca, presentacion, principio_activo, concentracion,
        codigo_barras, lote, laboratorio, precio_compra, precio_venta,
        id_categoria, requiere_receta, fecha_vencimiento
    ];

    db.query(sql, valores, (error, result) => {
        if (error) {
            console.error('Error al agregar producto:', error);
            return res.status(500).json({ error: 'Error al agregar producto' });
        }
        res.json({ mensaje: 'Producto agregado correctamente', id: result.insertId });
    });
});
// Actualizar un producto por ID
app.put('/productos/:id', (req, res) => {
    const id = req.params.id;
    const {
        nombre, descripcion, marca, presentacion, principio_activo, concentracion,
        codigo_barras, lote, laboratorio, precio_compra, precio_venta,
        id_categoria, requiere_receta, fecha_vencimiento
    } = req.body;

    // Validación básica de campos obligatorios
    if (!nombre || precio_compra === undefined || precio_venta === undefined || !id_categoria) {
        return res.status(400).json({ error: 'Faltan datos obligatorios' });
    }

    const sql = `
        UPDATE productos SET
            nombre = ?,
            descripcion = ?,
            marca = ?,
            presentacion = ?,
            principio_activo = ?,
            concentracion = ?,
            codigo_barras = ?,
            lote = ?,
            laboratorio = ?,
            precio_compra = ?,
            precio_venta = ?,
            id_categoria = ?,
            requiere_receta = ?,
            fecha_vencimiento = ?
        WHERE id_producto = ?
    `;

    const valores = [
        nombre, descripcion, marca, presentacion, principio_activo, concentracion,
        codigo_barras, lote, laboratorio, precio_compra, precio_venta,
        id_categoria, requiere_receta, fecha_vencimiento, id
    ];

    db.query(sql, valores, (error, result) => {
        if (error) {
            console.error('Error al actualizar producto:', error);
            return res.status(500).json({ error: 'Error al actualizar producto' });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Producto no encontrado' });
        }
        res.json({ mensaje: 'Producto actualizado correctamente' });
    });
});
// Eliminar un producto por ID
app.delete('/productos/:id', (req, res) => {
    const id = req.params.id;
    db.query('DELETE FROM productos WHERE id_producto = ?', [id], (error, result) => {
        if (error) {
            console.error('Error al eliminar producto:', error);
            return res.status(500).json({ error: 'Error al eliminar producto' });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Producto no encontrado' });
        }
        res.json({ mensaje: 'Producto eliminado correctamente' });
    });
});




//Inicia el servidor en el puerto especificado y ejecuta 
//una función callback cuando esté listo.
app.listen(PORT, () => {
//Imprime en consola un mensaje confirmando que el servidor está corriendo, 
// usando template literals para incluir el puerto.
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});